import json,re
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'content/curriculum.json'
d=json.loads(p.read_text(encoding='utf-8'))
def age(s):
 m=re.search(r'(\d+)\s*تا\s*(\d+)',str(s or ''))
 return int(m.group(1)) if m else 99
errors=[]
count=0
for dom in d['domains']:
 prev=None
 for lv in dom['levels']:
  lev_age=age(lv.get('ageBand') or (lv.get('lessons') or [{}])[0].get('ageBand'))
  for l in lv['lessons']:
   key=(age(l.get('ageBand')), l.get('difficulty',999), l.get('order',999))
   if prev and key < prev:
    errors.append((dom['id'],l['id'],prev,key))
   prev=key; count+=1
print({'lessons':count,'orderErrors':len(errors),'errors':errors[:10]})
raise SystemExit(1 if errors else 0)
